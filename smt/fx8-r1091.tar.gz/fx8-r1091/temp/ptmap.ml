(* include http://www.lri.fr/~filliatr/ftp/ocaml/ds/ptmap.ml *)

let test n =
  let ar = [| "ene"; "due"; "rabe"; "chinczyk"; "zlapal"; "zabe"; "asd"; "asds" |] in
  let a k = ar . (k land 7) in

  let rec loop t k =
    if k >= n then t
    else loop (add k (a k) t) (k + 1)
  in
  let t = loop empty 0 in
  let rec loop k =
    if k >= n then ()
    else (
      assert (mem k t);
      assert (find k t = a k);
      loop (k + 1))
  in loop 0
;;

test 1000000
