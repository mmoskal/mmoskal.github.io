typedef union {
        unsigned long long value;
        unsigned int ints[2];
} TSC_value;

#define rdtsc(v) \
        __asm__ __volatile__("rdtsc" : "=a" (v.ints[0]), "=d" (v.ints[1]))

long long read_tsc()
{
	TSC_value v;
	rdtsc(v);
	return v.value;
}
