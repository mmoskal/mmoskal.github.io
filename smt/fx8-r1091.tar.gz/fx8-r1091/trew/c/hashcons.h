#include <stdio.h>

typedef struct symbol {
	struct symbol *next;

	struct rule *rules;

	struct term *binding;
	int binding_depth;

	int id;
	char name[1];
} symbol;

typedef struct term {
	struct term *next;
	symbol *function;
	struct term *normal_form;
	int id;
	int var_level;
	int arity;
	struct term *saved;
	struct term *children[1];
} term;

typedef struct rule {
	struct rule *next;
	term *source;
	term *target;
	int arg_count;
} rule;

typedef struct sexpr {
	symbol *name;
	int arity;
	struct sexpr *children[1];
} sexpr;

extern symbol *sym_lambda, *sym_var, *sym_let;
extern symbol *sym_beta, *sym_skol, *sym_cons, *sym_nil;
extern symbol *sym_constant_fold, *sym_plus, *sym_minus, *sym_div, *sym_tilde;
extern symbol *sym_le, *sym_true, *sym_false;
extern symbol *sym_forall, *sym_exists, *sym_and, *sym_or, *sym_distinct;
extern symbol *sym_initial, *sym_pinitial, *sym_final, *sym_final_ok, *sym_skolemize;

extern term *term_zero;

#define true 1
#define false 0

void init_symbols(void);
symbol *get_symbol(char *name);
term *get_term(term *t);
term *get_const(symbol *s);
term *get_var(int lev);
term *get_lambda(term *t);
sexpr *alloc_sexpr(int arity);

void fatal(char *msg);
void print_term(char *msg, term *t);
extern int verbose, trusted_mode;
term *save_term(term *t);
void free_local_mem();
void mem_stats();
void *local_alloc(int size);


#define ALIGN(size) (((size) + sizeof(void*) - 1) & ~(sizeof(void*) - 1))


#define TERM_SIZE(t) (sizeof(term) + (((t)->arity - 1) * sizeof(term*)))
#define ALLOCA_TERM(t,arity_) \
	term *t = alloca(sizeof(term) + (((arity_) - 1) * sizeof(term*))); \
	t->arity = arity_; \
	memset(t, 0, TERM_SIZE(t)); \
	t->arity = arity_
#define FIX_VAR_LEVEL(t) \
	{ int i; \
	t->var_level = -1; \
	for (i = 0; i < t->arity; ++i) \
		if (t->children[i]->var_level > t->var_level) \
			t->var_level = t->children[i]->var_level; \
	} 
#define COPY_OF_TERM(c,t) term *c = alloca(TERM_SIZE(t)); memcpy(c, t, TERM_SIZE(t))
#define MAP_CHILDREN(orig,t,fn,same) \
	int same = true; \
	COPY_OF_TERM(t,orig); \
	t->normal_form = NULL; \
	t->saved = NULL; \
	{ \
		int i; \
		t->var_level = -1; \
		for (i = 0; i < t->arity; ++i) { \
			term* IT = t->children[i]; \
			term *tmp = fn; \
			if (IT != tmp) same = false; \
			t->children[i] = tmp; \
			if (tmp->var_level > t->var_level) \
				t->var_level = tmp->var_level; \
		} \
	}


/* rewrite.c */
term *nf(term *);
term *rule_app(term *);
term *offset(int n, term *t);
term *beta(term *m, term *n);
void read_rule(term *t);

/* sexpr.c */
sexpr *top_read_sexpr(FILE *f);
term *sexpr_to_term(sexpr *s);
term *read_benchmark(FILE *f);
