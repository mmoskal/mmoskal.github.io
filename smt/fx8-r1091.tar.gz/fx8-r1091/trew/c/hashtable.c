#include <stdlib.h>
#include <string.h>
#include "hashtable.h"
#include "hashcons.h"

void using_memory(int amount);

typedef struct _entry {
	struct _entry *next;
} *entry;

struct _hashtable
{
	unsigned (*hash)(void*);
	int (*equal)(void*,void*);
	int capacity;
	int length;
	entry *table;
};

hashtable h_create(int size, unsigned (*hash)(void*), int (*equal)(void*,void*))
{
	hashtable r = malloc(sizeof(*r));
	if (r == NULL) fatal("out of memory");
	r->hash = hash;
	r->equal = equal;
	r->capacity = size;
	r->length = 0;
	r->table = calloc(r->capacity, sizeof(entry));
	if (r->table == NULL) fatal("out of memory");
	using_memory(r->capacity * sizeof(entry) + sizeof(*r));
	return r;
}

#define INITIAL 123

void h_clear(hashtable r)
{
	using_memory(-(r->capacity - INITIAL) * sizeof(entry));
	free(r->table);
	r->capacity = INITIAL;
	r->length = 0;
	r->table = calloc(r->capacity, sizeof(entry));
	if (r->table == NULL) fatal("out of memory");
}

void h_free(hashtable r, void (*free_entry)(void*))
{
	if (free_entry != NULL) {
		int i;
		for (i = 0; i < r->capacity; ++i) {
			entry p, n;
			for (p = r->table[i]; p; p = n) {
				n = p->next;
				free_entry(p);
			}
		}
	}
	using_memory(-r->capacity * sizeof(entry) - sizeof(*r));
	free(r->table);
	free(r);
}

static void rehash(hashtable h)
{
	int capacity = h->capacity * 2 + 1;
	entry *table = calloc(capacity, sizeof(entry));
	if (table == NULL) fatal("out of memory [rehash]");
	int i;

	for (i = 0; i < h->capacity; ++i) {
		entry n, p;
		unsigned hash;
		for (p = h->table[i]; p; p = n) {
			n = p->next;
			hash = h->hash(p) % capacity;
			p->next = table[hash];
			table[hash] = p;
			p = n;
		}
	}

	using_memory(capacity * sizeof(entry));
	using_memory(-h->capacity * sizeof(entry));
	free(h->table);
	h->table = table;
	h->capacity = capacity;
}

void h_add(hashtable h, void *e_)
{
	unsigned hash;
	entry e = (entry)e_;

	if (h->capacity < h->length)
		rehash(h);
	
	hash = h->hash(e) % h->capacity;
	e->next = h->table[hash];
	h->table[hash] = e;
	h->length++;
}

void *h_find(hashtable h, void *e_)
{
	entry e = (entry)e_, p;
	unsigned hash = h->hash(e) % h->capacity;

	for (p = h->table[hash]; p; p = p->next)
		if (h->equal(e, p)) return p;
	return NULL;
}

