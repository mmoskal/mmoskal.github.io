typedef struct _hashtable *hashtable;
// element type has to have next field as first
hashtable h_create(int size, unsigned (*hash)(void*), int (*equal)(void*,void*));
void h_add(hashtable h, void *e);
void *h_find(hashtable h, void *e);
void h_clear(hashtable h);
void h_free(hashtable r, void (*free_entry)(void*));

