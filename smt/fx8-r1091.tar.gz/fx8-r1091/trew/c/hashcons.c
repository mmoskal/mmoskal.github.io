#include "hashtable.h"
#include "hashcons.h"
#include <alloca.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

symbol *sym_lambda, *sym_var, *sym_let;
symbol *sym_beta, *sym_skol, *sym_cons, *sym_nil;
symbol *sym_constant_fold, *sym_plus, *sym_minus, *sym_div;
symbol *sym_le, *sym_true, *sym_false, *sym_tilde;
symbol *sym_forall, *sym_exists, *sym_and, *sym_or, *sym_distinct;
symbol *sym_initial, *sym_pinitial, *sym_final, *sym_final_ok, *sym_skolemize;

term *term_zero;

int use_two_heaps;
static int max_malloc_mem_used, cur_malloc_mem_used;

static hashtable symbols;
static hashtable global_terms, local_terms;
static int sym_id, term_id;

typedef enum { GLOBAL, LOCAL } alloc_kind;

#define BLOCK_SIZE 64*1024

static char *local_ptr, *local_end, *global_ptr, *global_end;
static void *local_first_block, *local_to_free;
static int current_blocks, top_blocks;

void using_memory(int amount)
{
	cur_malloc_mem_used += amount;
	if (cur_malloc_mem_used > max_malloc_mem_used)
		max_malloc_mem_used = cur_malloc_mem_used;
}

static void *xmalloc(size_t sz)
{
	void *p = malloc(sz);
	if (p == NULL) {
		printf("memory used: %d k\n", current_blocks * BLOCK_SIZE / 1024);
		fatal("out of memory");
	}
	return p;
}

static void *alloc(alloc_kind k, int size)
{
	void *p;

	if (local_first_block == NULL) {
		local_ptr = xmalloc(BLOCK_SIZE);
		local_first_block = local_ptr;
		global_ptr = xmalloc(BLOCK_SIZE);
		local_end = local_ptr + BLOCK_SIZE;
		global_end = global_end + BLOCK_SIZE;
		current_blocks = 2;
	}

	size = ALIGN(size);

	if (use_two_heaps && k == LOCAL) {
		p = local_ptr;
		local_ptr += size;
		if (local_ptr > local_end) {
			local_ptr = xmalloc(BLOCK_SIZE);
			local_end = local_ptr + BLOCK_SIZE;
			current_blocks++;
			*((void**)local_ptr) = local_to_free;
			local_to_free = local_ptr;
			local_ptr += sizeof(void*);
			p = local_ptr;
			local_ptr += size;
		}
	} else {
		p = global_ptr;
		global_ptr += size;
		if (global_ptr > global_end) {
			global_ptr = xmalloc(BLOCK_SIZE);
			global_end = global_ptr + BLOCK_SIZE;
			current_blocks++;
			p = global_ptr;
			global_ptr += size;
		}
	}
	
	return p;
}

void *local_alloc(int size)
{
	return alloc(LOCAL, size);
}

void free_local_mem()
{
	if (current_blocks > top_blocks)
		top_blocks = current_blocks;

	if (use_two_heaps) {
		local_ptr = local_first_block;
		local_end = local_ptr + BLOCK_SIZE;

		void *p, *n;
		for (p = local_to_free; p; p = n) {
			n = *((void**)p);
			free(p);
			current_blocks--;
		}
		local_to_free = NULL;
		h_clear(local_terms);
	}
}

void mem_stats()
{
	printf("memory used: %d k (now %d k) (+ %d k malloc)\n", 
		top_blocks * BLOCK_SIZE / 1024,
		current_blocks * BLOCK_SIZE / 1024,
		max_malloc_mem_used / 1024);
}

static unsigned sym_hash(void *p)
{
	char *s = ((symbol*)p)->name;
	unsigned res = 0;
	while (*s) {
		res += *s++;
		res *= 13;
	}
	return res;
}

static int sym_equal(void *p1, void *p2)
{
	return strcmp(((symbol*)p1)->name, ((symbol*)p2)->name) == 0;
}

symbol *get_symbol(char *name)
{
	int size = sizeof(symbol) + strlen(name) + 1;
	symbol *sym = alloca(ALIGN(size));
	strcpy(sym->name, name);
	symbol *sym2 = h_find(symbols, sym);
	if (sym2 != NULL) return sym2;

	sym = alloc(GLOBAL, size);
	sym->id = ++sym_id;
	sym->binding = NULL;
	sym->rules = NULL;
	strcpy(sym->name, name);
	h_add(symbols, sym);

	return sym;
}

static unsigned term_hash(void *p)
{
	term *t = (term*) p;
	unsigned res = t->function->id ^ (t->var_level << 16) ^ (t->arity << 13);
	int i;

	for (i = 0; i < t->arity; ++i) {
		res *= 13;
		res += t->children[i]->id;
	}

	return res;
}

static int term_equal(void *p1, void *p2)
{
	term *t1 = p1, *t2 = p2;
	int i;

	if (t1->function != t2->function || t1->arity != t2->arity || t1->var_level != t2->var_level)
		return false;

	for (i = 0; i < t1->arity; ++i)
		if (t1->children[i] != t2->children[i])
			return false;
	
	return true;
}

term *get_term(term *t)
{
	term *res;
	int size;

	res = h_find(local_terms, t);
	if (res != NULL) return res;

	res = h_find(global_terms, t);
	if (res != NULL) return res;

	size = TERM_SIZE(t);
	res = alloc(LOCAL, size);
	memcpy(res, t, size);
	res->normal_form = NULL;
	res->id = ++term_id;

	h_add(local_terms, res);

	return res;
}

static term *st_copy(term *t)
{
	if (t->saved != NULL) {
		//print_term("term", t);
		//print_term("save", t->saved);
		//printf("%p -> %p\n", t, t->saved);
		//assert(((char*)t>=local_mem && (char*)t<=local_ptr) || t->saved == t);
		return t->saved;
	}
	
	//assert((char*)t>=local_mem && (char*)t<=local_ptr);
	
	int size = TERM_SIZE(t);
	term *res = alloc(GLOBAL, size);
	t->saved = res;
	memcpy(res, t, size);

	if (t->normal_form == t)
		res->normal_form = res;
	else if (t->normal_form != NULL)
		res->normal_form = st_copy(t->normal_form);

	int i;
	for (i = 0; i < t->arity; ++i)
		res->children[i] = st_copy(res->children[i]);
	
	assert(h_find(global_terms, res) == 0);
	h_add(global_terms, res);

	return res;
}

term *save_term(term *t)
{
	//print_term("save_term IN ", t);
	if (use_two_heaps)
		t = st_copy(t);
	//print_term("save_term OUT", t);
	return t;
}

term *get_var(int lev)
{
	struct term t = { NULL, sym_var, NULL, 0, lev, 0, 0, { NULL } };
	return get_term(&t);
}

term *get_lambda(term *t)
{
	struct term r = { NULL, sym_lambda, NULL, 0, t->var_level - 1, 1, 0, { t } };
	return get_term(&r);
}

term *get_const(symbol *s)
{
	struct term r = { NULL, s, NULL, 0, -1, 0, 0, { NULL } };
	return get_term(&r);
}

void init_symbols()
{
	symbols = h_create(7251, sym_hash, sym_equal);
	sym_lambda = get_symbol("\\");
	sym_var = get_symbol("%VAR");
	sym_let = get_symbol("let");
	sym_beta = get_symbol("%BETA");
	sym_skol = get_symbol("%SKOL");
	sym_cons = get_symbol("%CONS");
	sym_nil = get_symbol("%NIL");
	sym_constant_fold = get_symbol("%CONSTANT_FOLD");
	sym_plus = get_symbol("+");
	sym_minus = get_symbol("-");
	sym_div = get_symbol("%div");
	sym_le = get_symbol("<=");
	sym_true = get_symbol("true");
	sym_false = get_symbol("false");
	sym_tilde = get_symbol("~");

	sym_forall = get_symbol("forall");
	sym_exists = get_symbol("exists");
	sym_and = get_symbol("and");
	sym_or = get_symbol("or");
	sym_distinct = get_symbol("distinct");
	sym_initial = get_symbol("initial");
	sym_pinitial = get_symbol("%initial");
	sym_final = get_symbol("%final");
	sym_final_ok = get_symbol("%final_ok");
	sym_skolemize = get_symbol("skolemize");

	global_terms = h_create(7251, term_hash, term_equal);
	local_terms = h_create(123, term_hash, term_equal);

	term_zero = save_term(get_const(get_symbol("0")));
}

sexpr *alloc_sexpr(int arity)
{
	return (sexpr*) alloc(LOCAL, sizeof(sexpr) + (arity - 1) * sizeof(sexpr*));
}

static void print_term_aux(term *t)
{
	//printf("[%p]", t);
	if (t->arity == 0) {
		if (t->function == sym_var) {
			printf("v%d", t->var_level);
		} else {
			printf("%s", t->function->name);
		}
	} else {
		printf("%s(", t->function->name);
		int i;
		for (i = 0; i < t->arity; ++i) {
			print_term_aux(t->children[i]);
			if (i != t->arity - 1)
				printf(", ");
		}
		printf(")");
	}
}

void print_term(char *msg, term *t)
{
	printf("%s: ", msg);
	print_term_aux(t);
	printf("\n");
}
