#include "hashtable.h"
#include "hashcons.h"
#include <stdio.h>
#include <string.h>
#include <alloca.h>
#include <assert.h>
#include <ctype.h>
#include <stdlib.h>

void using_memory(int);

typedef struct cache_entry {
	struct cache_entry *next;
	int term;
	int depth;
	term *res;
} cache_entry;

static unsigned cache_hash(void *p)
{
	cache_entry *e = (cache_entry *)p;
	return e->term * 13 + e->depth;
}

static int cache_equal(void *p1, void *p2)
{
	cache_entry *e1 = (cache_entry*) p1;
	cache_entry *e2 = (cache_entry*) p2;
	return e1->term == e2->term && e1->depth == e2->depth;
}

static void free_cache(void *p)
{
	free(p);
	using_memory(-sizeof(struct cache_entry));
}

static term *save_entry(hashtable cache, cache_entry *e)
{
	cache_entry *p = malloc(sizeof(*e));
	using_memory(sizeof(*e));
	memcpy(p, e, sizeof(*e));
	h_add(cache, p);
	return p->res;
}

static term *offset_helper(hashtable cache, int n, int d, term *t)
{
	cache_entry e = { NULL, t->id, d, NULL };
	cache_entry *p = (cache_entry*)h_find(cache, &e);
	if (p != NULL)
		return p->res;

	if (t->var_level < 0)
		e.res = t;
	else if (t->function == sym_lambda)
		e.res = get_lambda(offset_helper(cache, n, d+1, t->children[0]));
	else if (t->function == sym_var) {
		e.res = t->var_level >= d ? get_var(t->var_level + n) : t;
	} else {
		MAP_CHILDREN(t, res, offset_helper(cache, n, d, IT), same);
		e.res = same ? t : get_term(res);
	}

	return save_entry(cache, &e);
}

term *offset(int n, term *t)
{
	if (n == 0) return t;

	hashtable cache = h_create(13, cache_hash, cache_equal);
	term *res = offset_helper(cache, n, 0, t);
	h_free(cache, free_cache);

	return res;
}

static void uniq_helper(hashtable cache, term *t)
{
	cache_entry e = { NULL, t->function->id, 0, NULL };
	cache_entry *p = (cache_entry*)h_find(cache, &e);

	if (p == NULL)
		save_entry(cache, &e);
	else
		if (p->res != NULL)
			fatal("trying to use a symbol previously used as skolem constant");

	if (t->function == sym_skolemize) {
		if (t->arity != 1 || t->children[0]->arity != 0)
			fatal("ill formed skolemize(...)");

		e.term = t->children[0]->function->id;
		if (h_find(cache, &e) != NULL) {
			printf("sym: %s %d\n", t->children[0]->function->name,
						t->children[0]->function->id);
			fatal("trying to reuse skolem function");
		}

		e.res = t;
		save_entry(cache, &e);

		return;
	}


	int i;
	for (i = 0; i < t->arity; ++i)
		uniq_helper(cache, t->children[i]);
}

void check_uniq(term *t1, term *t2)
{
	hashtable cache = h_create(13, cache_hash, cache_equal);
	uniq_helper(cache, t1);
	uniq_helper(cache, t2);
	h_free(cache, free_cache);
}

static term *beta_helper(hashtable cache, term *n, int x, term *t)
{
	cache_entry e = { NULL, t->id, x, NULL };
	cache_entry *p = (cache_entry*)h_find(cache, &e);
	if (p != NULL)
		return p->res;
	
	int donf = x == 0;

	if (t->var_level < 0) {
		e.res = donf ? nf(t) : t;
	} else if (t->function == sym_var) {
		if (t->var_level == x)
			e.res = donf ? nf(offset(x,n)) : offset(x,n);
		else
			e.res = x < t->var_level ? get_var(t->var_level - 1) : t;
	} else if (t->function == sym_lambda) {
		e.res = get_lambda(beta_helper(cache, n, x+1, t->children[0]));
	} else {
		MAP_CHILDREN(t, res, beta_helper(cache, n, x, IT), same);
		if (donf)
			e.res = (same && t->normal_form != NULL) ? t->normal_form : rule_app(res);
		else
			e.res = same ? t : get_term(res);
	}

	return save_entry(cache, &e);
}

term *beta(term *m, term *n)
{
	hashtable cache = h_create(13, cache_hash, cache_equal);
	term *res = beta_helper(cache, n, 0, m);
	h_free(cache, free_cache);
	return res;
}

static term **current_vars;
static rule *current_rule;
static int match_rule(term *t1, term *t2)
{
	int i;

	if (t1->function == sym_var) {
		int v = t1->var_level; 
		if (current_vars[v] == NULL)
			current_vars[v] = t2;
		return current_vars[v] == t2;
	}

	if (!(t1->function == t2->function && t1->arity == t2->arity))
		return false;
	
	for (i = 0; i < t1->arity; ++i)
		if (! match_rule(t1->children[i], t2->children[i]))
			return false;

	return true;
}

static term *rule_subst(int x, term *t)
{
	if (t->var_level < 0) return nf(t);

	if (t->function == sym_var) {
		if (t->var_level >= x) {
			int off = t->var_level - x;
			if (off < current_rule->arg_count)
				return offset(x, current_vars[off]);
			assert(false);
		} else {
			return t;
		}
	}

	if (t->function == sym_lambda)
		return get_lambda(rule_subst(x+1, t->children[0]));
	

	MAP_CHILDREN(t, res, rule_subst(x, IT), same);
	return (same && t->normal_form != NULL) ? t->normal_form : rule_app(res);
}

static term *try_apply(term *t, rule *r)
{
	if (verbose) {
		print_term("(try_apply on", t);
		print_term(" from", r->source);
		print_term("   to", r->target);
	}

	rule *prev_rule = current_rule;
	term **prev_vars = current_vars;

	current_rule = r;
	current_vars = alloca(r->arg_count * sizeof(term*));
	memset(current_vars, 0, r->arg_count * sizeof(term*));

	if (! match_rule(r->source, t)) {
		if (verbose) printf("fail)\n");
		current_rule = prev_rule;
		current_vars = prev_vars;
		return NULL;
	}

	t = rule_subst(0, r->target);

	current_rule = prev_rule;
	current_vars = prev_vars;
	if (verbose) printf("ok)\n");
	
	return t;
}

static int list_length(term *t)
{
	if (t->arity == 2 && t->function == sym_cons) {
		int sublen = list_length(t->children[1]);
		if (sublen < 0) return sublen;
		else return 1 + sublen;
	}
	if (t->arity == 0 && t->function == sym_nil) return 0;
	return -1;
}

#define IN_RANGE(v) ((v) < 100000000 && (v) > -100000000)

static int is_number(term *t, long *res)
{
	char *end;
	if (t->arity != 0) return 0;
	*res = strtol(t->function->name, &end, 10);
	if (*end == '\0' && IN_RANGE(*res))
		return 1;
	return 0;
}

static term *build_number(long n)
{
	if (!IN_RANGE(n))
		fatal("arithmetic overflow");
	char buf[20];
	sprintf(buf, "%ld", n);
	return get_const(get_symbol(buf));
}

static term *try_constant_fold(term *t)
{
	if (t->arity == 1) {
		long v;
		if ((t->function == sym_minus || t->function == sym_tilde) && is_number(t->children[0], &v))
			return build_number(-v);
	} else if (t->arity == 2) {
		term *a = t->children[0];
		term *b = t->children[1];
		long va=0, vb=0;
		int na = is_number(a,&va), nb = is_number(b,&vb);

		if (t->function == sym_plus) {
			if (na && nb)
				return build_number(va + vb);
			else if (a == term_zero)
				return b;
			else if (b == term_zero)
				return a;
		} else if (t->function == sym_minus) {
			if (na && nb)
				return build_number(va - vb);
			else if (b == term_zero)
				return a;
			else if (a == term_zero) {
				if (b->function == sym_tilde && b->arity == 1)
					return b->children[0];

				ALLOCA_TERM(res, 1);
				res->function = sym_tilde;
				res->children[0] = b;
				FIX_VAR_LEVEL(res);
				return get_term(res);
			}
		} else if (t->function == sym_div) {
			if (na && nb) {
				if (vb == 2) return build_number(va >> 1); 
				else return build_number(va / vb);
			}
		} else if (t->function == sym_le) {
			if (na && nb)
				return get_const(va <= vb ? sym_true : sym_false);
		}
	}
	
	return NULL;
}

term *rule_app(term *t)
{
	if (verbose) print_term("rule_app", t);

	if (t->function == sym_beta && t->arity == 2 && t->children[0]->function == sym_lambda)
		return beta(t->children[0]->children[0], t->children[1]);
	
	if (t->function == sym_skol && t->arity == 2 && t->children[0]->arity == 0) {
		int len = list_length(t->children[1]);
		if (len >= 0) {
			symbol *name = t->children[0]->function;
			ALLOCA_TERM(res,len);
			int i;
			term *p = t->children[1];
			res->function = name;
			for (i = 0; i < len; ++i) {
				assert(p->arity == 2);
				res->children[i] = p->children[0];
				p = p->children[1];
			}
			FIX_VAR_LEVEL(res);
			return get_term(res);
		}
	}

	if (t->function == sym_constant_fold && t->arity == 1) {
		term *res = try_constant_fold(t->children[0]);
		if (verbose) {
			print_term("constant_fold", t->children[0]);
			print_term("         --->", res);
		}
		if (res != NULL) return res;
	}

	t = get_term(t);
	if (t->normal_form != NULL)
		return t->normal_form;
	
	rule *r;
	for (r = t->function->rules; r; r = r->next) {
		term *res = try_apply(t, r);
		if (res != NULL) {
			t->normal_form = res;
			return res;
		}
	}

	t->normal_form = t;
	return t;
}

term *nf(term *t)
{
	if (t->normal_form != NULL) return t->normal_form;

	if (t->function == sym_lambda) {
		t->normal_form = get_lambda(nf(t->children[0]));
		return t->normal_form;
	}

	if (t->function == sym_var) {
		t->normal_form = t;
		return t;
	}

	MAP_CHILDREN(t, res, nf(IT), same);
	t->normal_form = rule_app(res);
	return t->normal_form;
}

static symbol *rr_vars[256];

static term *rr_aux(int depth, term *t)
{
	if (t->arity == 0 && isupper(t->function->name[0])) {
		int i;
		const int limit = sizeof(rr_vars)/sizeof(rr_vars[0]) - 3;
		for (i = 0; i < limit; ++i) {
			if (rr_vars[i] == NULL) break;
			if (rr_vars[i] == t->function)
				return get_var(i + depth);
		}
		if (i >= limit) fatal("rule var buffer overflow");
		rr_vars[i] = t->function;
		return get_var(i + depth);
	}

	if (t->function == sym_var)
		return t;

	if (t->function == sym_lambda)
		return get_lambda(rr_aux(depth + 1, t->children[0]));

	MAP_CHILDREN(t, res, rr_aux(depth, IT), same);
	return get_term(res);
}

void read_rule(term *t)
{
	if (!trusted_mode)
		fatal("rules allowed only in trusted mode");

	if (verbose>2) print_term("rrbefore", t);
	t = rr_aux(0, t);
	if (verbose>2) print_term("rrafteraux", t);
	assert(t->arity == 2 || t->arity == 3);

	int len = 0;
	while (rr_vars[len] != NULL)
		rr_vars[len++] = NULL;

	rule *r = malloc(sizeof(rule));
	using_memory(sizeof(rule));
	r->source = t->children[t->arity - 2];
	r->target = t->children[t->arity - 1];
	r->arg_count = len;

	if (verbose>2) printf("adding rule to %s\n", r->source->function->name);

	r->next = r->source->function->rules;
	r->source->function->rules = r;

	r->source = save_term(r->source);
	r->target = save_term(r->target);
}
