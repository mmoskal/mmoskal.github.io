#include "hashcons.h"
#include <stdio.h>
#include <string.h>
#include <alloca.h>
#include <assert.h>

static term *s2t_helper(int depth, sexpr *s)
{
	if (!trusted_mode && s->name->name[0] == '%')
		fatal("attempt to use restricte identifier in non-trusted mode");

	if (s->arity == 0) {
		symbol *sym = s->name;

		if (sym->binding == NULL)
			return get_const(sym);
		
		if (sym->binding_depth == -1)
			return sym->binding;
		
		return offset(depth - sym->binding_depth, sym->binding);
	}

	if (s->name == sym_let) {
		if (s->arity != 3 || s->children[0]->arity != 0)
			fatal("malformed let");
		term *m = s2t_helper(depth, s->children[1]);

		symbol *sym = s->children[0]->name;
		term *backup_binding = sym->binding;
		int backup_depth = sym->binding_depth;
		sym->binding = m;
		sym->binding_depth = depth;

		term *n = s2t_helper(depth, s->children[2]);

		sym->binding = backup_binding;
		sym->binding_depth = backup_depth;

		return n;
	}

	if (s->name == sym_lambda) {
		if (s->arity != 2 || s->children[0]->arity != 0)
			fatal("malformed \\");
		depth++;

		symbol *sym = s->children[0]->name;
		term *backup_binding = sym->binding;
		int backup_depth = sym->binding_depth;
		sym->binding = get_var(0);
		sym->binding_depth = depth;

		term *n = s2t_helper(depth, s->children[1]);

		sym->binding = backup_binding;
		sym->binding_depth = backup_depth;

		return get_lambda(n);
	}

	ALLOCA_TERM(res,s->arity);
	res->function = s->name;
	int i;
	for (i = 0; i < res->arity; ++i)
		res->children[i] = s2t_helper(depth, s->children[i]);
	FIX_VAR_LEVEL(res);
	return get_term(res);
}

term *sexpr_to_term(sexpr *s)
{
	return s2t_helper(0, s);
}

static term *s2s_helper(int depth, sexpr *s);
static term *s2s_quant_helper(int depth, sexpr *s, int i)
{
	sexpr *v = s->children[i];

	assert(i < s->arity);

	if (i == s->arity - 1 || s->children[i + 1]->name->name[0] == ':') {
		return s2s_helper(depth, v);
	}

	if (v->arity != 1)
		fatal("malformed var in quant");
	depth++;

	symbol *sym = v->name;
	term *backup_binding = sym->binding;
	int backup_depth = sym->binding_depth;
	sym->binding = get_var(0);
	sym->binding_depth = depth;

	term *n = s2s_quant_helper(depth, s, i + 1);

	sym->binding = backup_binding;
	sym->binding_depth = backup_depth;

	ALLOCA_TERM(res,1);
	res->function = s->name;
	res->children[0] = get_lambda(n);
	FIX_VAR_LEVEL(res);
	return get_term(res);
}

static term *s2s_nary_helper(int depth, sexpr *s, int i)
{
	assert(i < s->arity);
	term *us = s2s_helper(depth, s->children[i]);
	if (i == s->arity - 1)
		return us;

	ALLOCA_TERM(res,2);
	res->function = s->name;
	res->children[0] = us;
	res->children[1] = s2s_nary_helper(depth, s, i + 1);
	FIX_VAR_LEVEL(res);
	return get_term(res);
}

static term *s2s_helper(int depth, sexpr *s)
{
	if (s->arity == 0) {
		symbol *sym = s->name;

		if (sym->binding == NULL)
			return get_const(sym);
		
		if (sym->binding_depth == -1)
			return sym->binding;
		
		return offset(depth - sym->binding_depth, sym->binding);
	}

	if (s->name == sym_exists || s->name == sym_forall) {
		term *res = s2s_quant_helper(depth, s, 0);
		//print_term("quant_res", res);
		return res;
	}

	if (s->name == sym_and || s->name == sym_or || s->name == sym_distinct)
		return s2s_nary_helper(depth, s, 0);

	ALLOCA_TERM(res,s->arity);
	res->function = s->name;
	int i;
	for (i = 0; i < res->arity; ++i)
		res->children[i] = s2s_helper(depth, s->children[i]);
	FIX_VAR_LEVEL(res);
	return get_term(res);
}

static term *sexpr_to_smt(sexpr *s)
{
	return s2s_helper(0, s);
}

static int non_ws(FILE *f)
{
	int ch = fgetc(f);

	while (ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r')
		ch = fgetc(f);

	if (ch == ';') {
		while (ch >= 0 && ch != '\n')
			ch = fgetc(f);
		return non_ws(f);
	} else {
		return ch;
	}
}

static int peek(FILE *f)
{
	int ch = fgetc(f);
	if (ch >= 0) ungetc(ch, f);
	return ch;
}

static char wordbuf[1024 * 8];

static symbol *read_word(FILE *f)
{
	int pos = 0;
	int quoted = 0;
	int brace_level = 0;
	int ch = peek(f);

	if (ch == '"') {
		fgetc(f);
		quoted = 1;
	} else if (ch == '{') {
		fgetc(f);
		quoted = 1;
		brace_level = 1;
	}
	
	for (;;) {
		ch = fgetc(f);
		if (ch < 0) break;
		if (!quoted && strchr(" \t\r\n();", ch) != NULL) {
			ungetc(ch,f);
			break;
		}
		if (quoted && brace_level == 0 && ch == '"') break;
		if (brace_level > 0 && ch == '{') brace_level++;
		if (brace_level > 0 && ch == '}') {
			if (--brace_level == 0) break;
		}
		if ((unsigned)pos >= sizeof(wordbuf)/sizeof(wordbuf[0]) - 2)
			fatal("word buffer overflow");
		wordbuf[pos++] = ch;
	}

	wordbuf[pos] = 0;
	return get_symbol(wordbuf);
}


static sexpr *read_sexpr(FILE *f)
{
	int pos = 0;
	symbol *hd;
	int size = 10;
	sexpr *sargs_buf[size];
	sexpr **sargs = sargs_buf;

	if (peek(f) == '(') {
		fgetc(f);
		hd = read_word(f);
		for (;;) {
			int ch = non_ws(f);
			if (ch < 0)
				fatal("unexpected end of file");
			if (ch == ')')
				break;
			ungetc(ch, f);
			if (pos >= size - 2) {
				sexpr **newbuf = local_alloc(size * 3 * sizeof(sexpr*));
				memcpy(newbuf, sargs, (pos+1) * sizeof(sexpr*));
				size = size * 3;
				sargs = newbuf;
			}
			sargs[pos++] = read_sexpr(f);
		}
	} else {
		hd = read_word(f);
	}

	sexpr *res = alloc_sexpr(pos);
	res->name = hd;
	res->arity = pos;
	int i;
	for (i = 0; i < pos; ++i)
		res->children[i] = sargs[i];
	return res;
}

sexpr *top_read_sexpr(FILE *f)
{
	int ch = non_ws(f);
	if (ch < 0) {
		sexpr *res = alloc_sexpr(0);
		res->name = get_symbol("quit");
		return res;
	}

	ungetc(ch,f);
	return read_sexpr(f);
}

static void skip_ws(FILE *f)
{
	int ch = non_ws(f);
	ungetc(ch, f);
}

term *read_benchmark(FILE *f)
{
	int ch = non_ws(f);
	if (ch != '(')
		fatal("benchmark doesn't start with (");
	skip_ws(f);
	if (strcmp(read_word(f)->name, "benchmark") != 0) 
		fatal("benchmark doesn't start with (benchmark");
	skip_ws(f);
	printf("reading SMT file `%s'\n", read_word(f)->name);

	sexpr* args[1024 * 4];
	int pos = 0;
	for (;;) {
		ch = non_ws(f);
		if (ch == ')') break;
		ungetc(ch, f);
		symbol *w = read_word(f);
		int isform = strcmp(w->name, ":formula") == 0 || strcmp(w->name, ":assumption") == 0;
		skip_ws(f);
		sexpr *s = read_sexpr(f);
		if (isform) {
			args[pos++] = s;
			if ((unsigned)pos > sizeof(args) / sizeof(args[0]) - 3)
				fatal("SMT assumption limit exceeded");
		}
	}

	ch = non_ws(f);
	if (ch >= 0)
		fatal("junk at the end of benchmark file");
	
	sexpr *res = alloc_sexpr(pos);
	res->name = sym_and;
	res->arity = pos;
	int i;
	for (i = 0; i < pos; ++i)
		res->children[i] = args[i];
	
	return sexpr_to_smt(res);		
}
