#include "hashcons.h"
#include <stdio.h>
#include <string.h>
#include <alloca.h>
#include <assert.h>
#include <stdlib.h>

#ifdef __ARM_ARCH_4__
#define SARM 1
#include <sys/wcethread.h>
#endif

int verbose;
int trusted_mode;
term *query;
extern int use_two_heaps;

static char *trusted_files[10];
static int trusted_ptr;
static char *query_file, *proof_file;

void check_uniq(term *t1, term *t2);

void fatal(char *m)
{
	printf("FATAL: %s\n", m);

	#ifdef __ARM_ARCH_4__
	//fclose(stdout);
	fgetc(stdin);
	#endif

	exit(1);
}

static void read_file(char *name)
{
	FILE *f = fopen((char*)name, "r");
	if (f == NULL)
		fatal("cannot open input file");

	for (;;) {
		sexpr *top = top_read_sexpr(f);
		char *name = top->name->name;

		if (strcmp(name, "quit") == 0) {
			if (!trusted_mode)
				fatal("wanted to escape, huh!?");
			break;
		}
		
		if (strcmp(name, "coq") == 0) { }
		else if (strcmp(name, "initial") == 0 && top->arity == 2) {
			if (sym_initial->binding != NULL)
				fatal("a second attempt to initiate");
			term *t1 = sexpr_to_term(top->children[0]);
			term *t2 = sexpr_to_term(top->children[1]);
			if (query == NULL) {
				if (!trusted_mode)
					fatal("no query specified, either specify query with -q, or use trusted mode (-t)");
			} else {
				if (query != t2) {
					print_term("query", query);
					print_term("initial", t2);
					fatal("term passed to initial doesn't match the query");
				}
			}
			check_uniq(t1, t2);
			ALLOCA_TERM(ini, 2);
                        ini->function = sym_pinitial;
			ini->children[0] = t1;
			ini->children[1] = t2;
                        FIX_VAR_LEVEL(ini);
			term *body = nf(get_term(ini));
			if (verbose) printf("setting initial binding\n");
			sym_initial->binding = save_term(body);
			sym_initial->binding_depth = -1;
		}
		else if (strcmp(name, "final") == 0 && top->arity == 1) {
			term *t1 = sexpr_to_term(top->children[0]);

			ALLOCA_TERM(ini, 1);
                        ini->function = sym_final;
			ini->children[0] = t1;
                        FIX_VAR_LEVEL(ini);

			term *res = nf(get_term(ini));
			if (res->arity == 0 && res->function == sym_final_ok) {
				printf("proof OK\n");
				break;
			} else {
				print_term("final", res);
				fatal("final check failed");
			}
		}
		else if (strcmp(name, "eq_rule") == 0 ||
	            strcmp(name, "bool_rule") == 0 ||
	            strcmp(name, "skol_rule") == 0 ||
	            strcmp(name, "arith_rule") == 0 ||
	            strcmp(name, "trusted_rule") == 0 ||
	            strcmp(name, "raw_coq_rule") == 0 ||
	            strcmp(name, "rule") == 0)
			read_rule(sexpr_to_term(top));
		else if (strcmp(name, "let") == 0 && top->arity == 2 && top->children[0]->arity == 0) {
			term *body = sexpr_to_term(top->children[1]);
			if (verbose) print_term("let ", body);
			body = nf(body);
			if (verbose) print_term(" -> ", body);
			symbol *name = top->children[0]->name;
			if (verbose) printf("setting binding of %s\n", name->name);
			name->binding = save_term(body);
			name->binding_depth = -1;
		} else if (strcmp(name, "print") == 0 && top->arity == 1) {
			print_term(trusted_mode ? "trusted" : "proof", sexpr_to_term(top->children[0]));
		} else if (strcmp(name, "assert_eq") == 0 && top->arity == 2) {
			term *t1 = sexpr_to_term(top->children[0]);
			term *t2 = sexpr_to_term(top->children[1]);
			if (t1 != t2) {
				print_term("t1", t1);
				print_term("t2", t2);
				fatal("assert_eq failed");
			}
		} else if (strcmp(name, "assert_ok") == 0 && top->arity == 1) {
			term *t = sexpr_to_term(top->children[0]);
			t = nf(t);
			if (t->arity != 0 || strcmp(t->function->name, "%ok") != 0) {
				print_term("ok_term", t);
				fatal("assert_ok failed");
			}
		} else if (strcmp(name, "rem") == 0) { }
		else {
			printf("%s: ", name);
			fatal("bad magic word");
		}

		free_local_mem();
	}

	fclose(f);
}

unsigned long main_loop(void *dummy)
{
	(void)dummy;
	int items = 0;

	int i;
	trusted_mode = true;
	for (i = 0; trusted_files[i] != NULL; ++i) {
		printf("reading trusted file `%s'\n", trusted_files[i]);
		read_file(trusted_files[i]);
		items++;
	}
	trusted_mode = false;
	
	if (query_file != NULL) {
		FILE *f = fopen(query_file, "r");
		if (f == NULL)
			fatal("cannot open query file");
		query = save_term(read_benchmark(f));
		free_local_mem();
		fclose(f);
	}

	if (proof_file != NULL) {
		read_file(proof_file);
		items++;
	}

	if (items == 0)
		fatal("i'm a slacker and didn't do anything");

	return 0;
}

int main(int argc, char **argv)
{
	(void)argc;
	#ifdef __ARM_ARCH_4__
	//stdout = fopen("out.txt","w");
	#endif

	use_two_heaps = true;

	argv++;
	while (*argv) {
		char *arg = *argv++;
		if (arg[0] == '-' && arg[1] != 0 && arg[2] == 0)
			switch (arg[1]) {
			case '1':
				use_two_heaps = false;
				break;
			case 'v':
				verbose++;
				break;
			case 't':
				if (*argv == NULL)
					fatal("-t requires an argument");
				if (trusted_ptr >= 9)
					fatal("too much args");
				trusted_files[trusted_ptr++] = *argv++;
				break;
			case 'q':
				if (*argv == NULL)
					fatal("-q requires an argument");
				if (query_file != NULL)
					fatal("too many queries");
				query_file = *argv++;
				break;
			case 'p':
				if (*argv == NULL)
					fatal("-p requires an argument");
				if (proof_file != NULL)
					fatal("too many proofs");
				proof_file = *argv++;
				break;
			default:
				fatal("usage: trew [-v] [-1] [-t trusted.rw]... [-q query.smt] [-p proof.rw]");
				break;
			}
		else fatal("bad usage, try -?");
	}

	init_symbols();

	#ifdef __ARM_ARCH_4__
	// reserve 1 meg of stack, the 0x10000 means to allocate it right away, otherwise
	// it doesn't seem to work
	HANDLE handle = CreateThread(NULL, 1000000, main_loop, NULL, 0x00010000, NULL);
	WaitForSingleObject(handle, 1000000);
	#else
	main_loop(NULL);
	#endif

	mem_stats();

	#ifdef __ARM_ARCH_4__
	//fclose(stdout);
	fgetc(stdin);
	#endif
	return 0;
}

