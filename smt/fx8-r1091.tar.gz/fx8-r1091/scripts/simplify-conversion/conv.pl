$pref = "";

while (<>) {
  /NAME_PREFIX (\S+)\)/ and do { $pref = $1; next };
  /BG_PUSH/ and last;
  /^\s*$/ or die;
}

$bg = $_;
while (<>) {
  /^\s*$/ and last;
  $bg .= $_;
}


while (<>) {
/^;/ and last;
}

$first=$_;

$cnt = 1;

while (1) {
  $p = $first;
  $name = undef;
  while (<>) {
    $p .= $_;
    /file-name: (\S+)/ and $name = $1;
    /^;/ or /NEXT_INVALID/ or last;
  }
  $next = 0;
  while (<>) {
    $p .= $_;
    /^;;; total-time/ and next;
    /^;/ and do { $next = 1; $first = $_; last };
  } 

  defined $name or die;


  open(F,">spl/$name");
  $cnt++;
  print F "(NAME_PREFIX $name)\n";
  print F $bg;
  print F "\n\n\n";
  print F $p;
  close(F);

  $next or last;
}
