#!/usr/bin/perl


while (<>) {
  chomp;
  s/\s+//g;
  if (/.*(Vec.\d\d\d.smt)/ ) {
    print "$_\n" if ! $h{$1};
    $h{$1} = 1;
  } else {
    print "$_\n";
  }
}
