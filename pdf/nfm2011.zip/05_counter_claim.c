#include <vcc.h>
#include "atomic.h"
#include <limits.h>

_(claimable) struct Counter {
  volatile int v;
  _(invariant v == \old(v) || v == \old(v) + 1)
};

void increment(struct Counter *n)
  _(requires \wrapped(n))
  _(ensures \wrapped(n))
  // (1) will write the "reference count" of n
  _(writes n)
{
  _(ghost \claim r)
  int x, y;  

  _(atomic n) {
    x = n->v;
    // (2) inline object with invariant(x), referencing n
    _(ghost r = \make_claim({n}, x <= n->v))
  }

  _(assume x < INT_MAX - 10)

  // (3) use r here
  _(atomic n, r) {
    InterlockedCompareExchange(&n->v, x + 1, x);    
    _(assert x < n->v)
  }
}
