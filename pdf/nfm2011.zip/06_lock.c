#include <vcc.h>
#include "atomic.h"

// (1) mark that what \owns can change while closed
_(volatile_owns) struct Lock {
  volatile int locked;
  _(ghost \object protected_obj;)
  _(invariant locked == 0 ==> \mine(protected_obj))
};

void Acquire(struct Lock *l _(ghost \claim c))
  // (2) \wrapped(c) not \wrapped(l)
  _(requires \wrapped(c))
  _(requires \claims(c, l->\closed))  
  _(ensures \wrapped(l->protected_obj) && 
            \fresh(l->protected_obj))
{
  int stop = 0;

  do {
    _(atomic c, l) {
      stop = 
          InterlockedCompareExchange(&l->locked, 1, 0) == 0;
      _(ghost if (stop) 
           l->\owns -= l->protected_obj)
    }
  } while (!stop);
}

void Release(struct Lock *l _(ghost \claim c))
  _(always c, l->\closed)
  _(requires l->protected_obj != c)
  _(writes l->protected_obj)
  _(requires \wrapped(l->protected_obj))
{
  _(atomic c, l) {
    l->locked = 0;
    _(ghost l->\owns += l->protected_obj)
  }
}

void InitializeLock(struct Lock *l _(ghost \object obj))
  _(writes \span(l), obj)
  _(requires \wrapped(obj))
  _(ensures \wrapped(l) && l->protected_obj == obj)
{
  l->locked = 0;
  _(ghost {
    l->protected_obj = obj;
    l->\owns = {obj};
    _(wrap l)
  })
}

typedef struct _DATA {
  int a;
  int b;
  _(invariant a + b > 0)
} DATA;

// (3) data protected by the lock
struct Lock DataLock;
DATA Data;

// (4) make the connection explicit
_(ghost
_(claimable) struct _DATA_CONTAINER {
  int dummy;
  _(invariant \mine(&DataLock))
  _(invariant DataLock.protected_obj == &Data)
} DataContainer;)

// (5) gets claim on container, not the lock
void operate_on_data(_(ghost \claim c))
  _(always c, (&DataContainer)->\closed)
{
  // (6) acquires, updates, releases
  Acquire(&DataLock _(ghost c));
    _(unwrapping &Data) {
      Data.a = 5;
      Data.b = 7;
    }
  Release(&DataLock _(ghost c));
}

void boot()
  _(writes \universe())
  _(requires \program_entry_point())
{
  _(ghost \claim c;)

  Data.a = 42;
  Data.b = 17;
  _(wrap &Data)
  InitializeLock(&DataLock _(ghost &Data));
  _(ghost (&DataContainer)->\owns = {&DataLock, &DataContainer})
  _(wrap &DataContainer)

  _(ghost c = \make_claim({&DataContainer}, (&DataContainer)->\closed);)
  operate_on_data(_(ghost c));
}

