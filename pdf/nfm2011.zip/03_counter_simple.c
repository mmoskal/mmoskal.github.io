#include <vcc.h>
#include "atomic.h"
#include <limits.h>

struct Counter {
  // (1) volatile field can be updated when the object is closed
  volatile int v;  
  // (2) two-state invariant
  _(invariant v == \old(v) || v == \old(v) + 1)
};

void increment(struct Counter *n)
  _(requires \wrapped(n))
  // (3) no _(writes ...)
{
  int x;  
  
  // (4) updating n->*, check invariant over
  _(atomic n) {
    x = n->v;
  }

  _(assume x < INT_MAX - 10)

  _(atomic n) {
    InterlockedCompareExchange(&n->v, x + 1, x);
    // cannot prove it yet.
    _(assert x < n->v)
  }
}
