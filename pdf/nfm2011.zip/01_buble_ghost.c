#include <vcc.h>

// (1) logic function - like macros with better errors
_(logic bool sorted(int *buf, unsigned len) =
  \forall unsigned i, j; i < j && j < len ==> 
     buf[i] <= buf[j])

// (2) map - a big array
_(typedef unsigned perm_t[unsigned])

_(logic bool is_permutation(perm_t perm, unsigned len) =
  (\forall unsigned i, j;
    i < j && j < len ==> perm[i] < len && perm[i] != perm[j]))

// (3) explicit \state, \at()
_(logic bool is_permuted(\state s, int *buf, 
                         unsigned len, perm_t perm) =
  \forall unsigned i;  i < len ==> 
     perm[i] < len && \at(s, buf[perm[i]]) == buf[i])

// (4) ghost out parameter, explicitly constucted!
void bubble_sort_with_perm(int *buf, 
                           unsigned len 
                           _(out perm_t perm))
  _(writes \array_range(buf, len))
  _(ensures sorted(buf, len))
  _(ensures is_permutation(perm, len))
  _(ensures is_permuted(\old(\now()), buf, len, perm))
{
  int swapped;
  // (5) capture the state here
  _(ghost \state s0 = \now())

  // (6) a lambda expression
  _(ghost perm = \lambda unsigned i; i)

  if (len == 0) return;

  do
    _(invariant is_permutation(perm, len))
    _(invariant is_permuted(s0, buf, len, perm))
  {
    int tmp;
    unsigned i;

    swapped = 0;
    for (i = 0; i < len - 1; ++i)
      _(invariant !swapped ==> sorted(buf, i + 1))
      _(invariant is_permutation(perm, len))
      _(invariant is_permuted(s0, buf, len, perm))
    {
      if (buf[i] > buf[i + 1]) {
        tmp = buf[i + 1];
        buf[i + 1] = buf[i];
        buf[i] = tmp;
        _(ghost {
          unsigned tmpIdx = perm[i];
          perm[i] = perm[i + 1];
          perm[i + 1] = tmpIdx;
        })
        swapped = 1;
      }
    }

  }
  while (swapped);
}
