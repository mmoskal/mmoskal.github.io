#include <vcc.h>
#include <stdlib.h>

// (1) define a set of ints (should be in library)
_(typedef bool intset[int])
_(logic intset add1(intset s, int k) = 
  \lambda int i; s[i] || i == k)
_(logic intset empty() = \lambda int i; \false)

_(dynamic_owns)
struct List {
  // (2) public abstraction (ignore invariant for now)
  _(ghost intset val)

  // (7) concrete state
  struct Node *head;
 
  // (8) ownership dynamically defined through invariants
  _(invariant head != NULL ==> \mine(head))
  _(invariant \forall struct Node *n;
                \mine(n) ==> 
                    n->next == NULL || \mine(n->next))
  
  // (9) followers[n] - ints from n forward
  _(ghost bool followers[struct Node *][int])
  _(invariant \forall struct Node *n; 
                \mine(n) ==> 
                   \forall int e; 
                      followers[n][e] <==> 
                      followers[n->next][e] || e == n->data)
  _(invariant followers[NULL] == \lambda int k; \false)
  // coupling invariant
  _(invariant val == followers[head])
};

struct Node {
  struct Node *next;
  int data;
};

struct List *mklist()
  // (3) returns a \wrapped, empty list
  _(ensures \result != NULL ==> 
       \wrapped(\result) && \result->val == empty())
{
  struct List *l = (struct List*)malloc(sizeof(*l));
  if (l == NULL) return NULL;
  l->head = NULL;
  _(ghost {
    // (10) explicit updates of ownership
    l->\owns = {};
    l->followers = \lambda struct Node *n; int k; \false;
    l->val = l->followers[l->head];
  })
  // (11) check invariant, "close" the object
  _(wrap l)
  return l;
}

int add(struct List *l, int k)
  // (4) typical mutator method, spec can be shortened to _(updates l)
  _(updates l)
  // (5) behavior
  _(ensures \result == 0 ==> l->val == add1(\old(l->val), k))  
  _(ensures \result != 0 ==> l->val == \old(l->val))  
{
  struct Node *n = (struct Node*)malloc(sizeof(*n));
  if (n == NULL) return -1;
  // (12) open it up
  _(unwrap l)
    n->next = l->head;
    n->data = k;
    l->head = n;
    _(ghost {
      l->\owns += n;
      l->followers[n] = 
          \lambda int z; l->followers[n->next][z] || z == k;
      l->val = l->followers[n];
    })
  // (13) close and check
    _(wrap n)
  _(wrap l)
  return 0;
}

int member(struct List *l, int k)
  // (6) observer method
  _(requires \wrapped(l))
  _(ensures \result != 0 <==> l->val[k])
{
  struct Node *n;

  for (n = l->head; n; n = n->next)
    _(invariant n != NULL ==> n \in l->\owns)
    _(invariant l->val[k] <==> l->followers[n][k])
  {
    if (n->data == k)
      return 1;
  }
  return 0;
}
