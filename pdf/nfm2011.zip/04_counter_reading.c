#include <vcc.h>
#include "atomic.h"
#include <limits.h>

struct Counter {
  volatile int v;  
  _(invariant v == \old(v) || v == \old(v) + 1)
  // (1) never unwraps (will drop that later)
  _(invariant \on_unwrap(\this, \false))
};

// (2) ordinary object invariant represents a stable assertion
_(ghost 
struct CounterReading {
  int a;
  struct Counter *c;
  // (3) talks about non-owned c
  _(invariant c->\closed)
  _(invariant c->v >= a)
})

void increment(struct Counter *n)
  _(requires \wrapped(n))
{
  int x, y;  
  _(ghost struct CounterReading r)

  _(atomic n) {
    x = n->v;
  }
  // (4) imagine this is *in* the atomic block
  _(ghost { r.a = x; r.c = n; })
  _(wrap &r)

  _(assume x < INT_MAX - 10)

  _(atomic n) {
    InterlockedCompareExchange(&n->v, x + 1, x);
    // (5) when proving the assertion use r's invariant
    _(assert \inv(&r))
    _(assert x < n->v)
  }

  // (6) get rid of r
  _(unwrap &r)
}
