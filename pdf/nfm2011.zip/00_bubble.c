#include <vcc.h>
#include <limits.h>

// (3) \forall, ==> (otherwise C)
#define sorted(buf, len) \
    (\forall unsigned a, b; a < b && b < len ==> \
        buf[a] <= buf[b])

void bubble_sort(int *buf, unsigned len)
  // (1) _(...), \keyword
  // (2) requires/ensures/writes
  _(requires len > 0)
  _(ensures sorted(buf, len))
  _(writes \array_range(buf, len))
{
  int swapped;

  
  do
  {
    int tmp;
    unsigned i;
    
    swapped = 0;
    for (i = 0; i < (len - 1); ++i)
      _(invariant !swapped ==> sorted(buf, i + 1))
    {
        buf[i + 1] = INT_MAX;
    }
  }
  while (swapped);
}
